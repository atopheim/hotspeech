"""
Hotspeech - Voice recording and transcription application
"""

__version__ = "0.1.0"
