"""
Web UI package for Hotspeech
"""
